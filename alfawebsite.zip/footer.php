	</div>
	<footer>
		<div class="normal-foot"></div>
		<div class="rotate-foot"></div>
	</footer>
	<script src="main.js"></script>  
</body>
</html>