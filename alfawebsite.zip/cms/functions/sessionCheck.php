<?php 
class SCheck 
{
    public function __construct()
    {
        
    }
}