<?php 
include_once(sprintf('%s%scms%spages%scms-panel%spanel-head.php', DIRR, DS, DS, DS, DS)); 

echo 'Maintance';

include_once(sprintf('%s%scms%spages%scms-panel%spanel-foot.php', DIRR, DS, DS, DS, DS));