<?php include_once(sprintf('cms-panel%spanel-head.php', DS)); ?>

<div class="content">
    <h2 class="page-title">Welcome <?php echo $_SESSION['user']; ?></h2>
</div>

<?php include_once(sprintf('cms-panel%spanel-foot.php', DS)); ?>